list(list(foo=1,bar=list(11,22,33),baz=3), c(2,4,4,5), list(may=5,june='july'))
matrix(data=1:8, nrow=4, ncol=2, dimnames=list(c("x","y","z","a"), c("foo","bar")))

writeLines("foo")
